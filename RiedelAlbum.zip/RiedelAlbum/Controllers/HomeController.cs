﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RiedelAlbum.Models;

namespace RiedelAlbum.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private AlbumModel _data = new RiedelAlbum.Models.AlbumModel();

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            _data = GetData();
        }
        /// <summary>
        /// This method sets the data for use throughout the application. 
        /// The data is static, ie, it will not change throughout the session. So,
        /// you can then pass it around views w/o any issues.
        /// </summary>
        /// <returns></returns>
        private AlbumModel GetData()
        {
            //get json data
            var client = new WebClient();
            var users = client.DownloadString("https://jsonplaceholder.typicode.com/users");
            var albums = client.DownloadString("https://jsonplaceholder.typicode.com/albums");
            var photos = client.DownloadString("https://jsonplaceholder.typicode.com/photos");
            var posts = client.DownloadString("https://jsonplaceholder.typicode.com/posts");

            //deserialize json data
            List<Album> albumList = JsonConvert.DeserializeObject<List<Album>>(albums);
            List<Post> postList = JsonConvert.DeserializeObject<List<Post>>(posts);
            List<Photo> photoList = JsonConvert.DeserializeObject<List<Photo>>(photos);
            List<User> userList = JsonConvert.DeserializeObject<List<User>>(users);

            //populate ppties from deserialized json data
            var data = new RiedelAlbum.Models.AlbumModel();
            data.allUsers = userList.ToList<User>();
            data.allAlbums = albumList.ToList<Album>();
            data.allPhotos = photoList.ToList<Photo>();
            data.allPosts = postList.ToList<Post>();
            return data;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Album()
        {
            //pass on data to view
            return View(_data);
        }   
        public IActionResult Details(int id)
        {
            //pass on data to view
            int i = id;
            return View(_data);
        }
        public IActionResult Search(string searchString)
        {
            /*
             // Check the list for part #1734. This calls the IEquatable.Equals method
            // of the Part class, which checks the PartId for equality.
                Console.WriteLine("\nContains: Part with Id=1734: {0}",
                    parts.Contains(new Part { PartId = 1734, PartName = "" }));

                // Find items where name contains "seat".
                Console.WriteLine("\nFind: Part where name contains \"seat\": {0}", 
                    parts.Find(x => x.PartName.Contains("seat")));
        
                // Check if an item with Id 1444 exists.
                Console.WriteLine("\nExists: Part with Id=1444: {0}", 
                parts.Exists(x => x.PartId == 1444));             
             */
            
            string title = "Title not searched for";
            string address = "Address not searched for";
            string email = "Email not searched for";
            string name = "Name not searched for";
            Album searchAlbum = _data.allAlbums.Find(t => t.title == searchString);
            User searchUser = _data.allUsers.Find(n => n.name == searchString);

            if (searchAlbum == null && searchUser == null)
            {
                title = "Title not found";
                address = "Address not found";
                email = "Email not found";
                name = "Name not found";
            }
            else if (searchUser != null)
            {
                title = "Title not searched for";
                address = searchUser.address.street;
                email = searchUser.email;
                name = searchUser.name;
            }
            else
            {
                title = searchAlbum.title;
                address = "Address not searched for";
                email = "Email not searched for";
                name = "Name not searched for";
            }
            _data.searchResults = new Search(title, name, address, email);
            return View(_data);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
