﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RiedelAlbum.Models;

namespace RiedelAlbum.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private AlbumModel _data = new RiedelAlbum.Models.AlbumModel();

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            _data = GetData();
        }

        /// <summary>
        /// This method sets the data for use throughout the application. 
        /// The data is static, ie, it will not change throughout the session. So,
        /// you can then pass it around views w/o any issues.
        /// </summary>
        /// <returns></returns>
        private AlbumModel GetData()
        {
            //get json data
            var client = new WebClient();
            var users = client.DownloadString("https://jsonplaceholder.typicode.com/users");
            var albums = client.DownloadString("https://jsonplaceholder.typicode.com/albums");
            var photos = client.DownloadString("https://jsonplaceholder.typicode.com/photos");
            var posts = client.DownloadString("https://jsonplaceholder.typicode.com/posts");

            //deserialize json data
            List<Album> albumList = JsonConvert.DeserializeObject<List<Album>>(albums);
            List<Post> postList = JsonConvert.DeserializeObject<List<Post>>(posts);
            List<Photo> photoList = JsonConvert.DeserializeObject<List<Photo>>(photos);
            List<User> userList = JsonConvert.DeserializeObject<List<User>>(users);

            //populate ppties from deserialized json data
            var data = new RiedelAlbum.Models.AlbumModel();
            data.allUsers = data.displayUsers = userList.ToList<User>(); //start out w/ entire dataset for both lists
            data.allAlbums = albumList.ToList<Album>();
            data.allPhotos = photoList.ToList<Photo>();
            data.allPosts = postList.ToList<Post>();
            data.pageSize = 5;
            data.itemCount = userList.ToList<User>().Count;
            data.pageNumber = data.itemCount / data.pageSize;

            return data;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Album(int page)
        {
            if (page == 0 || page == 1) page = 0;
            else page = _data.itemCount / _data.pageNumber;

            int a = _data.itemCount;
            int b = _data.pageSize;
            int c = _data.itemCount;

            //user list drives the site, so even though the other lists have more items, it will not through a null exeption error
            _data.displayUsers = _data.allUsers; //reset for next page
            _data.displayUsers = _data.allUsers.GetRange(page, _data.allUsers.Count - _data.pageSize);

            //pass on data to view
            return View(_data);
        }
        public IActionResult AlbumDetails()
        {
            //pass on data to view
            //int i = id;
            //List<Photo> albumPhotos = _data.allPhotos.FindAll(i => i.albumId == id);
            return View(_data);
        }
        public IActionResult PersonDetails(int id)
        {
            return View(_data);
        }
        public IActionResult Search(string searchString)
        {            
            string title = "Title not searched for";
            string address = "Address not searched for";
            string email = "Email not searched for";
            string name = "Name not searched for";
            Album searchAlbum = _data.allAlbums.Find(t => t.title == searchString);
            User searchUser = _data.allUsers.Find(n => n.name == searchString);

            if (searchAlbum == null && searchUser == null)
            {
                title = "Title not found";
                address = "Address not found";
                email = "Email not found";
                name = "Name not found";
            }
            else if (searchUser != null)
            {
                title = "Title not searched for";
                address = searchUser.address.street + "; " + searchUser.address.city + "; " + searchUser.address.zipcode;
                email = searchUser.email;
                name = searchUser.name;
            }
            else
            {
                title = searchAlbum.title;
                address = "Address not searched for";
                email = "Email not searched for";
                name = "Name not searched for";
            }
            _data.searchResults = new Search(title, name, address, email);
            return View(_data);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
