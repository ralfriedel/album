﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RiedelAlbum.Models
{

    public class AlbumModel
    {
        public List<User> allUsers { get; set; }
        public List<User> displayUsers { get; set; } //for pagination
        public List<Album> allAlbums { get; set; }
        public List<Photo> allPhotos { get; set; }
        public List<Post> allPosts { get; set; }
        public Search searchResults { get; set; }
        public int pageSize { get; set; }
        public int pageNumber { get; set; }
        public int itemCount { get; set; }
    }
    public class Album
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title { get; set; }
    }
    public class Photo
    {
        public int albumId { get; set; }
        public int id { get; set; }
        public string title { get; set; }
        public string url { get; set; }
        public string thumbnailUrl { get; set; }
    }
    public class Post
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title { get; set; }
        public string body { get; set; }
    }
    public class Search
    {
        public string albumTitle { get; set; }
        public string userName { get; set; }
        public string userAddress { get; set; }
        public string userEmail { get; set; }

        public Search(string title, string name, string address, string email)
        {
            albumTitle = title;
            userName = name;
            userAddress = address;
            userEmail = email;
        }
    }

    //classes for user
    public class Geo
    {
        public string lat { get; set; }
        public string lng { get; set; }
    }

    public class Address
    {
        public string street { get; set; }
        public string suite { get; set; }
        public string city { get; set; }
        public string zipcode { get; set; }
        public Geo geo { get; set; }
    }

    public class Company
    {
        public string name { get; set; }
        public string catchPhrase { get; set; }
        public string bs { get; set; }
    }

    public class User
    {
        public int id { get; set; }
        public string name { get; set; }
        public string username { get; set; }
        public string email { get; set; }
        public Address address { get; set; }
        public string phone { get; set; }
        public string website { get; set; }
        public Company company { get; set; }
    }
}
